let player;
let enemies = [];
let healthKits = [];
let score = 0;
let isGameRunning = false;
let touchStartPos = { x: 0, y: 0 };
let touchCurrentPos = { x: 0, y: 0 };

// Sound setup
let isSoundEnabled = true;
let bgMusic;
let healthPickupSound;

function setupSound() {
    bgMusic = new Tone.Loop((time) => {
        const synth = new Tone.Synth().toDestination();
        synth.triggerAttackRelease("C4", "8n", time);
        synth.triggerAttackRelease("E4", "8n", time + 0.5);
        synth.triggerAttackRelease("G4", "8n", time + 1);
    }, 2).start(0);

    healthPickupSound = new Tone.Synth({
        oscillator: { type: "sine" },
        envelope: { attack: 0.01, decay: 0.1, sustain: 0.3, release: 0.1 }
    }).toDestination();

    // Start audio context on user interaction
    select('#startButton').mousePressed(() => {
        if (Tone.context.state !== 'running') {
            Tone.start();
        }
    });
}

function setup() {
    const canvas = createCanvas(800, 600);
    canvas.parent('gameCanvas');
    textSize(32);
    textAlign(CENTER, CENTER);

    resetGame();
    setupControls();
    setupSound();
    noLoop(); // Start with the game paused
}

function resetGame() {
    player = {
        x: width / 2,
        y: height / 2,
        size: 40,
        speed: 5,
        health: 100
    };

    enemies = [];
    for (let i = 0; i < 3; i++) {
        enemies.push({
            x: random(width),
            y: random(height),
            size: 30,
            speed: random(2, 4)
        });
    }

    healthKits = [];
    score = 0;
    updateHealthBar();
}

function setupControls() {
    // Start button
    select('#startButton').mousePressed(() => {
        isGameRunning = true;
        select('#startButton').attribute('disabled', '');
        select('#stopButton').removeAttribute('disabled');
        select('#gameOver').addClass('d-none');
        if (isSoundEnabled) {
            Tone.Transport.start();
        }
        loop();
    });

    // Stop button
    select('#stopButton').mousePressed(() => {
        isGameRunning = false;
        select('#stopButton').attribute('disabled', '');
        select('#startButton').removeAttribute('disabled');
        Tone.Transport.stop();
        noLoop();
    });

    // Sound toggle
    select('#soundToggle').mousePressed(() => {
        isSoundEnabled = !isSoundEnabled;
        const button = select('#soundToggle');
        if (isSoundEnabled) {
            button.html('🔊 Sound: On');
            if (isGameRunning) Tone.Transport.start();
        } else {
            button.html('🔈 Sound: Off');
            Tone.Transport.stop();
        }
    });

    // Restart button
    select('#restartButton').mousePressed(() => {
        resetGame();
        select('#gameOver').addClass('d-none');
        select('#startButton').removeAttribute('disabled');
        select('#stopButton').attribute('disabled', '');
        isGameRunning = false;
        Tone.Transport.stop();
        noLoop();
    });

    // Touch controls
    const touchArea = select('.touch-area').elt;
    touchArea.addEventListener('touchstart', handleTouchStart, false);
    touchArea.addEventListener('touchmove', handleTouchMove, false);
    touchArea.addEventListener('touchend', handleTouchEnd, false);
}

function handleTouchStart(event) {
    event.preventDefault();
    const touch = event.touches[0];
    touchStartPos = { x: touch.clientX, y: touch.clientY };
    touchCurrentPos = { ...touchStartPos };
}

function handleTouchMove(event) {
    event.preventDefault();
    const touch = event.touches[0];
    touchCurrentPos = { x: touch.clientX, y: touch.clientY };
}

function handleTouchEnd() {
    touchStartPos = { x: 0, y: 0 };
    touchCurrentPos = { x: 0, y: 0 };
}

function draw() {
    background(32);

    if (!isGameRunning) {
        fill(200);
        text('Press Start to Play!', width/2, height/2);
        return;
    }

    // Update player position
    if (keyIsDown(UP_ARROW)) player.y = max(player.y - player.speed, player.size/2);
    if (keyIsDown(DOWN_ARROW)) player.y = min(player.y + player.speed, height - player.size/2);
    if (keyIsDown(LEFT_ARROW)) player.x = max(player.x - player.speed, player.size/2);
    if (keyIsDown(RIGHT_ARROW)) player.x = min(player.x + player.speed, width - player.size/2);

    // Handle touch movement
    if (touchCurrentPos.x !== touchStartPos.x || touchCurrentPos.y !== touchStartPos.y) {
        const dx = touchCurrentPos.x - touchStartPos.x;
        const dy = touchCurrentPos.y - touchStartPos.y;
        const moveSpeed = player.speed * 0.5;

        player.x = constrain(player.x + (dx * moveSpeed / 50), player.size/2, width - player.size/2);
        player.y = constrain(player.y + (dy * moveSpeed / 50), player.size/2, height - player.size/2);
    }

    // Draw player
    textSize(player.size);
    text('👻', player.x, player.y);

    // Update and draw enemies
    enemies.forEach(enemy => {
        // Move towards player
        let dx = player.x - enemy.x;
        let dy = player.y - enemy.y;
        let dist = sqrt(dx * dx + dy * dy);

        enemy.x += (dx / dist) * enemy.speed;
        enemy.y += (dy / dist) * enemy.speed;

        // Draw enemy
        textSize(enemy.size);
        text('💀', enemy.x, enemy.y);

        // Check collision
        if (dist < (player.size + enemy.size) / 2) {
            player.health -= 1;
            updateHealthBar();

            if (player.health <= 0) {
                endGame();
            }
        }
    });

    // Spawn health kits randomly
    if (frameCount % 180 === 0 && random() < 0.5) {
        healthKits.push({
            x: random(width),
            y: random(height),
            size: 30,
            glowing: false
        });
    }

    // Draw and check health kits
    healthKits = healthKits.filter(kit => {
        textSize(kit.size);
        if (kit.glowing) {
            push();
            fill(255, 100);
            circle(kit.x, kit.y, kit.size * 1.5);
            pop();
        }
        text('❤️', kit.x, kit.y);

        let dist = sqrt(pow(player.x - kit.x, 2) + pow(player.y - kit.y, 2));
        if (dist < (player.size + kit.size) / 2) {
            if (isSoundEnabled) {
                healthPickupSound.triggerAttackRelease("C5", "8n");
            }
            player.health = min(player.health + 20, 100);
            updateHealthBar();
            return false;
        }

        // Add glowing effect
        kit.glowing = sin(frameCount * 0.1) > 0;
        return true;
    });

    // Update score
    if (frameCount % 60 === 0) {
        score += 10;
        select('#scoreValue').html(score);
    }
}

function updateHealthBar() {
    const healthBar = select('#healthBar');
    healthBar.style('width', `${player.health}%`);
    healthBar.html(`${player.health}%`);
}

function endGame() {
    isGameRunning = false;
    select('#gameOver').removeClass('d-none');
    select('#finalScore').html(score);
    select('#startButton').removeAttribute('disabled');
    select('#stopButton').attribute('disabled', '');
    Tone.Transport.stop();
    noLoop();
}